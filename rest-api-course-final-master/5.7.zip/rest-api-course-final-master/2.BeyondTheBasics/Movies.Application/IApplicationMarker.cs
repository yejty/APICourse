﻿namespace Movies.Application;

public interface IApplicationMarker {}
